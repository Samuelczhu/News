package com.example.administrator;

public class Web {

    private String title;
    private String time;
    private String content;
    private String url;
    private String picUrl;

    public Web(String title, String time, String content, String url, String picUrl) {
        this.title = title;
        this.time = time;
        this.content = content;
        this.url = url;
        this.picUrl = picUrl;
    }

    public String getTitle() {
        return title;
    }

    public String getTime() {
        return time;
    }

    public String getContent() {
        return content;
    }

    public String getUrl() {
        return url;
    }

    public String getPicUrl() {
        return picUrl;
    }
}
