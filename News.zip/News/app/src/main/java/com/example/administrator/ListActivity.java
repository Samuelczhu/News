package com.example.administrator;

import android.app.LoaderManager;
import android.content.Context;
import android.content.Intent;
import android.content.Loader;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class ListActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<List<Web>> {

    final String KEY = "KEY FOR URL";
    final String titleKEY = "KEY FOR TITLE";
    private static final String LOG_TAG = ListActivity.class.getName();
    private static String USGS_REQUST_URL;

    private TextView emptyTextView;
    private WebAdapter webAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        //Get the url from the main activity
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            USGS_REQUST_URL = extras.getString(KEY);
            setTitle(extras.getString(titleKEY));
        }

        ListView listView = (ListView) findViewById(R.id.list);

        emptyTextView = (TextView) findViewById(R.id.empty_view);
        listView.setEmptyView(emptyTextView);

        webAdapter = new WebAdapter(this, new ArrayList<Web>());
        listView.setAdapter(webAdapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Web currentWeb = webAdapter.getItem(position);
                Uri webUri = Uri.parse(currentWeb.getUrl());
                Intent webIntent = new Intent(Intent.ACTION_VIEW, webUri);
                startActivity(webIntent);
            }
        });


        // get a reference to teh ConnectivityManager to check the state of network
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        //if there is a network connection, fetch data
        if (networkInfo != null && networkInfo.isConnected()) {
            LoaderManager loaderManager = getLoaderManager();
            loaderManager.initLoader(1, null, this);
        } else {
            View loadingIndicator = findViewById(R.id.loading_indicator);
            loadingIndicator.setVisibility(View.GONE);

            emptyTextView.setText(R.string.no_internet_connection);
        }
    }

    @Override
    public Loader<List<Web>> onCreateLoader(int id, Bundle args) {
        return new WebLoader(this, USGS_REQUST_URL);
    }

    @Override
    public void onLoadFinished(Loader<List<Web>> loader, List<Web> data) {
        View loadingIndicator = findViewById(R.id.loading_indicator);
        loadingIndicator.setVisibility(View.GONE);

        //set the empty text to display "No news found."
        emptyTextView.setText(R.string.no_news);
        //clear the webAdapter
        webAdapter.clear();

        if (webAdapter != null && !data.isEmpty()) {
            webAdapter.addAll(data);
        }
    }

    @Override
    public void onLoaderReset(Loader<List<Web>> loader) {
        webAdapter.clear();
    }
}
