package com.example.administrator;

import android.content.AsyncTaskLoader;
import android.content.Context;

import java.util.List;

public class WebLoader extends AsyncTaskLoader<List<Web>> {

    private static final String LOG_TAG = WebLoader.class.getName();

    private String url;

    public WebLoader(Context context, String url) {
        super(context);
        this.url = url;
    }

    @Override
    protected void onStartLoading() {
        forceLoad();
    }

    @Override
    public List<Web> loadInBackground() {
        if (this.url == null) {
            return null;
        }

        //perform the network request
        List<Web> webs = QueryUtils.fetchWebData(url);
        return webs;
    }
}
