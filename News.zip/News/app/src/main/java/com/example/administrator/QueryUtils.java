package com.example.administrator;

import android.text.TextUtils;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

public class QueryUtils {

    private static final String LOG_TAG = QueryUtils.class.getSimpleName();

    private QueryUtils() {}

    public static List<Web> fetchWebData(String requstUrl) {
        URL url = createUrl(requstUrl);

        //perform HTTP request and receive a JSON response back
        String jsonResponse = null;
        try {
            jsonResponse = makeHTTPRequest(url);
        } catch (IOException e) {
            Log.e(LOG_TAG, "problem making the HTTP request.", e);
        }

        List<Web> webs = extractFeatureFromJson(jsonResponse);

        return webs;
    }

    //create url from string
    private static URL createUrl(String stringUrl) {
        URL url = null;
        try {
            url = new URL(stringUrl);
        } catch (MalformedURLException e) {
            Log.e(LOG_TAG, "problem building the URL", e);
        }
        return url;
    }

    //make an http request from url and return a json string as the response
    private static String makeHTTPRequest(URL url) throws IOException {
        String jsonResponse = "";

        //if the url is null. then return directly
        if (url == null) {
            return jsonResponse;
        }

        HttpURLConnection urlConnection = null;
        InputStream inputStream = null;
        try {
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setReadTimeout(10000);//milliseconds
            urlConnection.setConnectTimeout(15000);//15s
            urlConnection.setRequestMethod("GET");
            urlConnection.connect();

            //if the request was successful then read the input stream and parse the response
            if (urlConnection.getResponseCode() == 200) {
                inputStream = urlConnection.getInputStream();
                jsonResponse = readFromStream(inputStream);
            } else {
                Log.e(LOG_TAG,"Error response code: "+urlConnection.getResponseCode());
            }
        } catch (IOException e) {
            Log.e(LOG_TAG, "Problem retrieving the web JSON results.", e);
        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
            if (inputStream != null) {
                inputStream.close();
            }
        }
        return jsonResponse;
    }
    //reading the jsonResponse from an input stream
    private static String readFromStream(InputStream inputStream) throws IOException {
        StringBuilder output = new StringBuilder();
        if (inputStream != null) {
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream, Charset.forName("UTF-8"));
            BufferedReader reader = new BufferedReader(inputStreamReader);
            String line = reader.readLine();
            while (line != null) {
                output.append(line);
                line = reader.readLine();
            }
        }
        return output.toString();
    }

    // extract a web list for json string
    private static List<Web> extractFeatureFromJson(String  webJSON) {
        if (TextUtils.isEmpty(webJSON)) {
            return null;
        }

        //create an emptry arrayList
        List<Web> webs = new ArrayList<>();

        //try to parse the json response string
        try {
            //create a JSONObject from response string
            JSONObject baseJsonResponse = new JSONObject(webJSON);
            JSONObject result = baseJsonResponse.getJSONObject("result");
            JSONArray list = result.getJSONArray("list");

            for (int i=0;i<list.length();i++) {
                JSONObject currentWeb = list.getJSONObject(i);

                String title = currentWeb.getString("title");
                String time = currentWeb.getString("time");
                String content = currentWeb.getString("content");
                String url = currentWeb.getString("url");
                String picUrl = currentWeb.getString("pic");

                if (picUrl.equals("")  || picUrl.equals(null)) {
                    picUrl = "https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=2598815564,1393662255&fm=27&gp=0.jpg";
                }

                //add the web object into the arrayList
                webs.add(new Web(title, time, content, url, picUrl));
            }
        } catch (JSONException e) {
            Log.e("QueryUtils","Problem parsing the web JSON results",e);
        }
        return webs;
    }
}
