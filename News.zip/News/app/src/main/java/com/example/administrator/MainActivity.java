package com.example.administrator;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {

    final String KEY = "KEY FOR URL";
    final String titleKEY = "KEY FOR TITLE";
    String url = "http://api.jisuapi.com/news/get";
    String urlKey = "appkey=6e920e88bf4ba1ae";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //setting listener on each linear layout
        LinearLayout touTiao = (LinearLayout) findViewById(R.id.tou_tiao);
        touTiao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startIntent("头条");
            }
        });

        LinearLayout xingWen = (LinearLayout) findViewById(R.id.xing_wen);
        xingWen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startIntent("新闻");
            }
        });

        LinearLayout caiJing = (LinearLayout) findViewById(R.id.cai_jing);
        caiJing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startIntent("财经");
            }
        });

        LinearLayout tiYv = (LinearLayout) findViewById(R.id.ti_yu);
        tiYv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startIntent("体育");
            }
        });

        LinearLayout yvLe = (LinearLayout) findViewById(R.id.yv_le);
        yvLe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startIntent("娱乐");
            }
        });

        LinearLayout junShi = (LinearLayout) findViewById(R.id.jun_shi);
        junShi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startIntent("军事");
            }
        });

        LinearLayout keJi = (LinearLayout) findViewById(R.id.ke_ji);
        keJi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startIntent("科技");
            }
        });

        LinearLayout nba = (LinearLayout) findViewById(R.id.nba);
        nba.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startIntent("NBA");
            }
        });
    }

    private void startIntent(String name) {
        Intent intent = new Intent(MainActivity.this, ListActivity.class);
        intent.putExtra(KEY, url+"?channel="+name+"&"+urlKey);
        intent.putExtra(titleKEY, name);
        startActivity(intent);
    }
}
